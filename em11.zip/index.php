<!-- TODO dont use src tags to one server so its unblockablm via 9999 llinks-->
<?php
// So bascally when we require a file it will print out the html/css/js in the file
require('BackendAsset/VersionResolver.php'); // Takes the version (e.g. ?x=98) and fetches the wallpaper, name to put on the button, and the icon.
echo '<title>'.$ver.'</title>'; // Sets the title of the page (the name you see in the tabs). This PHP code is the same as writing "<title>Emulate11!</title>" in HTML.
require('BackendAsset/ModuleResolver.php'); // This loads jQuery, an extension of JavaScript. It lets us drag and resize windows.
require('BackendAsset/StyleResolver.php'); // This loads the CSS styles (how everything looks)
                                           // If it's not windows 11, 10, or dark mode then it's like ?x=7
                                           // So it gets the styles from Unpkg which hosts windows xp 7 and 98 styles
                                           // Otherwise it gets the styles from styles/style.css which is how Emulate11 looks
require('BackendAsset/GlobalStyles.php'); // Idk what this is for but it makes the background not look glitchy/streched
require('BackendAsset/WindowSummon.php'); // JavaScript code to spawn windows inside the div named "winbox" and minimze/hide them

?>

<div id="winbox">
  <!-- When BackendAsset/WindowSummon.php wants to summon a new window the code for the window (a window is a really fancy "textbox" except it displays a website embedded) is added here-->
</div>

<!-- Taskbar -->
<div id="nonwinbtns" style="position:absolute;bottom:0;left:0;">
    <!-- Code that shows all the elements it displays when Windows button is clicked -->
    <div id="buttonopts" style="opacity:0;pointer-events:none;">
      <select name="theme" id="theme">
      <option selected disabled> Choose a theme.. </option>
      <option value="/?x=98">Win 98 (Mantained by Mark)</option>
      <option value="/?x=xp">Win XP (Mantained by Mark)</option>
      <option value="/?x=dxp">Win XP Dark Mode (Mantained by Mayank)</option>
      <option value="/?x=7">Win 7 (Mantained by Mark)</option>
      <option value="/?x=welon">MATERWELON (MMMMMM WELON)</option>  
      <option value="/?x=10">Win 10 (Mantained by Mayank and Mark)</option>
      <option value="/?x=11">Win 11 (Mantained by Mayank and Mark)</option>
      <option value="/?x=dark">Win 11 Dark Mode (Mantained by Mayank)</option>
      </select>
      <button type="button" onclick="window.location=document.getElementById('theme').value"> Restart To Theme </button>
      <br/>
      <button type="button" style="background-color:none;outline:none;border:none;" onclick="location.reload();"> Update And Restart </button> 
      <br/>
      <script>
        const addCSS = css => document.head.appendChild(document.createElement("style")).innerHTML=css;
      </script>
      <button type="button" onclick="addCSS('iframe{opacity:1;}');">Disable Transparency</button>
      <button type="button" onclick="addCSS('iframe{opacity:0.5;}');">Enable Transparency</button>
      <br/>
      <button type="button" onclick="document.getElementById('slider').style.opacity='0';document.getElementById('slider').style.pointerEvents='none';document.getElementById('slider').value=0;"> Disable Multiple Desktops [ Goes To Center ] </button>
      <button type="button" id="abc" onclick="document.getElementById('slider').style.opacity='1';document.getElementById('slider').style.pointerEvents='auto';"> Enable Multiple Desktops </button>
      <br/>
      <button type="button" onclick="document.getElementById('datetime').style.opacity='0';document.getElementById('datetime').style.pointerEvents='none';"> Disable Clock </button>
      <button type="button" onclick="document.getElementById('datetime').style.opacity='1';document.getElementById('datetime').style.pointerEvents='auto';"> Enable Clock </button>
      <br/>
      <button type="button" onclick="document.getElementById('notifs').style.opacity='0';document.getElementById('notifs').style.pointerEvents='none';"> Disable Notifications </button>
      <button type="button" onclick="document.getElementById('notifs').style.opacity='1';document.getElementById('notifs').style.pointerEvents='auto';"> Enable Notifications </button>
      <br/>
      <button type="button" onclick="document.getElementById('winbtns').style.opacity='0';document.getElementById('winbtns').style.pointerEvents='none';"> Hide WindowList </button>
      <button type="button" onclick="document.getElementById('winbtns').style.opacity='1';document.getElementById('winbtns').style.pointerEvents='auto';"> Show WindowList </button>
      <br/>
      <script>
      function setBg() {
        addCSS(document.getElementById("bg").value);
      }
      function setImgBg() {
        addCSS("body {background-image:url('"+document.getElementById("bg2").value+"');}");
      }
      </script>              
      <input type="textbox" id="bg" placeholder="StyleRule" class="stylerule"/>
      <button type="button" onclick="setBg()">Set Style Rule</button><br/>
      <input type="textbox" id="bg2" placeholder="Background Image" class="stylerule"/>
      <button type="button" onclick="setImgBg()">Set Background</button><br/>
      <script>
        function launchue() {
          // const w = window.open() // access the "about:blank" window you've opened
          // w.document.body.innerHTML = document.body.inerHTML;
          window.open('about:blank').document.write(document.documentElement.innerHTML);
        }
      </script>
      <button onclick="launchue()"> Launch Unblockable Edition Directly (No Download Needed) </button><br/>
      <a style="background-color:black;color:white;text-decoration:none;opacity:0.5;font-size:14px;border-raidus:8px 8px 8px 8px;" href="javascript:(function()%7B(function()%20%7Bvar%20x%20%3D%20document.createElement(%22script%22)%3Bx.src%20%3D%20%22https%3A%2F%2Fcdn.jsdelivr.net%2Fgh%2FSnowLord7%2Fdevconsole%40master%2Fmain.js%22%3Bx.onload%20%3D%20alert(%22Loaded%20Developer%20Console!%22)%3Bdocument.head.appendChild(x)%3B%7D)()%7D)()"> Enable Developer Mode </a><br/>
      <a style="background-color:black;color:white;text-decoration:none;opacity:0.5;font-size:14px;border-raidus:8px 8px 8px 8px;" href="offline_edition.html" download="offline_edition.html">Download unblockable edition (Legacy Setting)</a>
    </div>
    <!-- Windows button -->
    <button type="button" class="taskbar" style="bottom:0;background-color:none;outline:none;border:none;" onclick="ToggleDisp();">Emulate11</button> 
    <!-- Apps launcher -->
    <select class="taskbar" name="apps" id="apps" onclick="populateApp()">
    <option value="about:blank" selected disabled> Select an app... </option>
    <option value="https://airforceaircade.com/"> U.S. Air Force Arcade Website </option> 
    <option value="MyApps/other.php">App From Link</option>
    <option value="https://v2.mkcodes.repl.co/"> Chat </option>
    <option value="https://ora.sh/"> GPT 3.5 </option>
    <option value="https://ora.sh/openai/gpt4"> GPT 4 </option>
    <option value="https://passioneffort.com/">Inflopnito</option>
    <option value="https://theoxymoron.xyz/">Inflopnito Fallback #1</option>
    <option value="MyApps/textbox.php<?php PrintDark("?theme=dark"); ?>">Notes</option>
    <option value="https://photopea.com/">Photoshop</option>
    <option value="https://mail.tm/">Temporary Mail</option>
    <option value="MyApps/appstore.php<?php PrintDark("?theme=dark"); ?>">[ AppStore ]</option>
    <option value="MyApps/gamestore.php<?php PrintDark("?theme=dark"); ?>">[ GameStore ]</option>
<!--    <option value="https://schoolhelp.mkcodes.repl.co/?dir=/home/runner/schoolhelp/files">School Help !!! -->
  </select>
  <!-- The code to show the buttons to show windows when they minimized are added here. The buttons show the window and self-destruct when clicked.-->
  <div id="winbtns" class="taskbar" style="display:inline-block;">
    <!--style="position:absolute;top:2.5%;left:1%;text-align:center;width:100%;"-->
  </div>
  <!-- The transparent taskbar. styles/style.css edits this div to add the transparency effect to 10% of the bottom of the screen-->
  <div id="taskbaroverlay">
    <!--TaskbarOverlay-->
  </div>
</div>
<!-- This div contains a slider that adjusts the position of all windows left or right when the slider is moved. -->
<div id="multipledesktops">
  <input id="slider" type="range" style="width:100%;z-index:99999999999999999999;margin:0;padding:0%;position:fixed;left:0;top:0;opacity:0;pointer-events:none;" onchange="test1();" min="-8000" max="8000" value="0" step="1" />
  <script>
  function test1() {
    //Loop through windowinstances and append pos by drag..
    $('div[id^=\'container\']').css( "left", document.getElementById('slider').value);
  }
  // setTimeout(test1, 1000);
  </script>
</div>
<!-- The clock. the style="..." code makes it positioned at bottom right. -->
<script>
  function getTime() {
    var datetime = new Date().toLocaleTimeString();
    var d = (new Date()).toString().split(' ').splice(1,3).join(' ');
    document.getElementById("datetime").innerText = d + " " + datetime;
  }
</script>
<button id="datetime" onclick="setInterval(getTime, 1000)" style="bottom:0%;right:0%;position: absolute;margin:auto;display:fixed;" class="taskbar"> Click to Start Clock (Uses System Resources) </button>

<!-- The notifications. Placed on the top right, the code to add text and remove the text when the [x] button is clicked is appended to this notification bar. -->
<div id="notifs" style="right:1.5%;text-align:right;opacity:0.5;position:absolute;">
  <br/>
</div>
<script>
// This is the Javascript code to add a notification and remove it when the [x] button is clicked
  // It does this by adding text and a button to remove the text and the button when clicked
function notify(title, text) {
  mtime = Date.now().toString()+Math.random().toString()
  document.getElementById("notifs").innerHTML+=`  <span id="tempnotice${mtime}" class="notif" style="opacty:0.5;border:16px;" class="taskbar"><b>${title}</b> <p style="display:inline-block;">${text}</p> <button type="button" onclick="document.getElementById(\'tempnotice${mtime}\').remove()" class=\'taskbar\'>[x]</button><br /></span>`;
}

// These notifications trigger when the OS starts / code is loaded
notify("‪", "ALWAYS resize a window before dragging to prevent glitches")
notify("Only use Emulate11 when you're done with your work!", "Chrome Unblocked is now blocked ;-;‪")
//u20a2 = ₢ // I used to add these notifications
// notify("Dont accidentally click the slider instead of the window", "the slider is multiple dekstops")
// notify("[ READ ALL: ] Drag and resize a window before using anything in it or the lag will be impeccable! Also resize & drag windows smoothly.")
</script>
<?php
// Secret code :p i will explain this when the feature is released
if (isset($_GET['fgMasteryconnect'])) {
  echo '<iframe id="exframe" src="https://student.masteryconnect.com/" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none; z-index:-99;"></iframe>';
  echo '<title>Student</title>';
  echo '<link rel="shortcut icon" href="https://student.masteryconnect.com/assets/favicon-2e869fe8fa.ico"/>';
  echo file_get_contents("BackendAsset/AutoConfig.php");
}
?>