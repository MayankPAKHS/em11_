<!--XSS WARNING: DO NOT ADD ANY APPS TO THIS UNTIL IM DONE THERE IS RISK OF XSS-->
<?php

require('AppComponent.ThemeAdapter.php');
// require('AppComponent.AppStoreStyle.php');
function addNewApp($link, $name, $author) {
  echo "<div style='text-align:right;'>";
  echo "<button type=\"button\" onclick=\"parent.InstallApp('".$name."', '".$link."');this.style.backgroundColor='green';this.innerHTML=' Installed! ';this.disabled=true;\"> Install Now </button>";
  echo "</div>";
  echo "<img style='width:32px;height:32px;' src='https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=".$link."&size=256' />";
  echo "<h3 style='display: inline-block;'> ".$name." ‪‪</h3>";
  echo "<p style='display: inline-block;'> by ".$author." ‪</p>";
  echo "<hr/>";
}
// sort by alphabetical order
addNewApp("https://among-us-online-fan-remake.1tim.repl.co/","Among Us", "1tim");
addNewApp("https://woomy.arras.cx/", "Arras.IO For School", "Woomy Arras Developers");
addNewApp("CSTM: https://www.chess.com/play", "Chess.com", "Erik Allebest");
addNewApp("CSTM: https://eaglercraft.ru/", "EaglerCraft", "Lax1Dude, ThisIsALegitUsername");
addNewApp("CSTM: https://working6.naaga-kartheekk.repl.co/", "EaglerCraft Server", "Kartheek");
addNewApp("https://garticphone.com", "Gartic Phone", "Onrizon");
addNewApp("https://stopots.com/system/", "StopotS", "Onrizon");
addNewApp("https://kahoot.it/", "Kahoot", "Kahoot! ASA");
addNewApp("https://minesweeper.us/", "MineSweeper", "Microsoft & Minesweeper.us Team");
addNewApp("https://coopminesweeper.com/", "MineSweeper Co-Op", "Timovski & Mystify");
addNewApp("https://turbowarp.org/389464290/embed?fps=30", "Getting over it", "Griffpatch");
addNewApp("https://narrow.one/", "Narrow One", "Pelican Party Studios");
addNewApp("https://turbowarp.org/220672247/embed?fps=120", "Osu! Mania", "OliBomby and Osu! Team");
addNewApp("https://web.libretro.com/", "RetroArch Web (Laggy)", "RetroArch and Emscripten Developers");
addNewApp("https://scuffeduno.online/", "Scuffed Uno", "Freddie Nelson");
addNewApp("https://mathactivity.xyz", "ShellShockers Fallback Proxy", "Blue Wizard Digital");
addNewApp("https://mathdrills.life", "ShellShockers Fallback Proxy", "Blue Wizard Digital");
addNewApp("https://yolk.quest/", "ShellShockers Fallback Proxy", "Blue Wizard Digital");
addNewApp("CSTM: https://sm64web.clambam10.repl.co/f.html", "Super Mario 64", "Nintendo, INC. // Web mantained by Clambam10 using WASM");
addNewApp("https://turbowarp.org/590926828/embed?/fps=60", "Terraria", "Re-logic & Griffpatch");
addNewApp("https://territorial.io/", "Territorial.IO", "David Tschacher");
addNewApp("https://tileman.io/", "Tileman.IO", "pea");
addNewApp("https://turbowarp.org/662849680/embed?", "Tetris", "jujulescratcheur");
addNewApp("https://emulatorgames.net/", "EmulatorGames", "EmulatorGames owner");
addNewApp("https://gba.js.org/", "GameBoy Advance Emulator", "N/A");
addNewApp("https://geometrydashlite.io/", "Geometry Dash Lite", "N/A");
addNewApp("https://sarra.io/", "Sarra.IO (Arras #2)", "Arras.IO devs. [Only works at home!]");
?>