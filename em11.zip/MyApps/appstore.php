<!--XSS WARNING: DO NOT ADD ANY APPS TO THIS UNTIL IM DONE THERE IS RISK OF XSS-->
<?php

require('AppComponent.ThemeAdapter.php');
// require('AppComponent.AppStoreStyle.php');
function addNewApp($link, $name, $author) {
  echo "<div style='text-align:right;'>";
  echo "<button type=\"button\" onclick=\"parent.InstallApp('".$name."', '".$link."');this.style.backgroundColor='green';this.innerHTML=' Installed! ';this.disabled=true;\"> Install Now </button>";
  echo "</div>";
  echo "<img style='width:32px;height:32px;' src='https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=".$link."&size=256' />";
  echo "<h3 style='display: inline-block;'> ".$name." ‪‪</h3>";
  echo "<p style='display: inline-block;'> by ".$author." ‪</p>";
  echo "<hr/>";
}
addNewApp("https://bash.gg/", "Bash Game Launcher", "Bash GG Developers");
addNewApp("https://modestumbrella2.com/", "Bash Game Launcher (Fallback Proxy)", "Bash GG Developers");
addNewApp("https://bing.com", "Bing", "Microsoft, Inc.");
addNewApp("CSTM: https://www.chess.com/play", "Chess.com", "Erik Allebest");
addNewApp("https://calculator.apps.chrome/", "ChromeApps: Calculator", "Alphabet, INC.");
addNewApp("CSTM: https://meet.google.com/", "ChromeApps: Meet", "Alphabet, INC.");
addNewApp("https://desmos.com/calculator", "Desmos Calculator", "Desmos, INC.");
addNewApp("/MyApps/NonDefault/drive.php", "Google Drive", "Alphabet, Inc.");
addNewApp("https://kahoot.it/", "Kahoot", "Kahoot! ASA");
addNewApp("https://kiwiirc.com/", "Kiwi IRC", "Kiwi IRC Developers");
addNewApp("https://v2.mkcodes.repl.co/", "Legacy Chat", "NamTheWinner and MKCodes");
addNewApp("https://jspaint.app/", "Paint95", "Isaiah Odhner");
addNewApp("https://todo.bookie0.repl.co/", "Todo App", "Bookie0");
addNewApp("https://novnc.com/noVNC/vnc.html", "VNC Connect", "noVNC");
addNewApp("https://rfet.mayankpandey9.repl.co/", "[INDEV] RFetch Proxy", "@mkcodes [ Developer of Emulate11 ]");
addNewApp("https://emulate11proxytest.mkcodes.repl.co/", "[UNSTABLE] PHP-Proxy", "Developers of PHP Proxy");
?>