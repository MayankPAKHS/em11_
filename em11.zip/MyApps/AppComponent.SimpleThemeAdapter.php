<style>
<?php
if ($_GET['theme'] == 'dark') {
  echo file_get_contents("../styles/simple/dark.css");
  echo '*{background-color:black;color:white;}';
} else {
  echo file_get_contents("../styles/simple/norm.css");
}
?>
</style>