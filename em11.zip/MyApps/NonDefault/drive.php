<link rel="favicon" src="src="https://ssl.gstatic.com/images/branding/product/1x/drive_2020q4_32dp.png" />
<img src="https://ssl.gstatic.com/images/branding/product/1x/drive_2020q4_32dp.png" />
<input type="textbox" id="s" />
<button type="button" onclick='window.location=document.getElementById("s").value'> Open Google Drive File </button>
<p> Other links might work but are known to refuse to connect, and some may be viruses.</p>
