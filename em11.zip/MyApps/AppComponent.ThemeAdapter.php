<style>
<?php
if ($_GET['theme'] == 'dark') {
  echo file_get_contents("../styles/styledark.css");
  echo '*{background-color:black;color:white;}';
} else {
  echo file_get_contents("../styles/style.css");
}
?>
</style>