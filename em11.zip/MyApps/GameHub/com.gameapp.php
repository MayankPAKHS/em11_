<body style="width:100%;">
  <hr style="top:10%;"/>
  <hr style="bottom:10%;"/>
</body>