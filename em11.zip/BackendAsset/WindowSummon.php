<script>
function launchFullScreen(element) {
  // Full Screen Function
  element = document.getElementById(element)
  if(element.requestFullScreen) {
    element.requestFullScreen();
  } else if(element.mozRequestFullScreen) {
    element.mozRequestFullScreen();
  } else if(element.webkitRequestFullScreen) {
    element.webkitRequestFullScreen();
  }
}

function ToggleDisp() {
  // Alternates opacity to 100% and 0% (show, don't show)
  var x = document.getElementById("buttonopts");
  if (x.style.opacity === "1") {
    x.style.opacity = "0";
    x.style.pointerEvents = 'none';
  } else {
    x.style.opacity = "1";
    x.style.pointerEvents = 'auto';
  }
}

var z_index_counter = 0; // Latest ZIndex = This+1
windowInstances = []

function new_window(id, link, title) {
  // Creates a window
  windowInstances.push(id);
  var slider = document.getElementById('slider').value;
  var faviconlink = `https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=${link}&size=256`;
  
  // Container div helps keep track of style, logs the change in window position from the slider
  // Draggable div for jquery drag func
  var html_template = `
<style>
  
  #draggable${id} {
    top: 1;
    left: 1;
    position: absolute;
  }
  
</style>
<script>
  
  function minm${id}() {
    document.getElementById('container${id}').style.opacity = '0';
    document.getElementById('container${id}').style.zIndex = '-1';
    document.getElementById('frame${id}').style.pointerEvents = 'none';
    document.getElementById("winbtns").innerHTML += \`<button type='button' class='taskbar' onclick='document.getElementById("container${id}").style.opacity = "1";document.getElementById("frame${id}").style.pointerEvents = "auto";updatezindex${id}();this.remove();'> <img src='${faviconlink}' style='bottom:0;display:inline-block;width:13px;height:13px;' /> ${title} </button> \`;
    $('#apps').prop('selectedIndex', 0);
  }
  function maxm${id}() {
    document.getElementById('draggable${id}').style.width = "100%";
    document.getElementById('draggable${id}').style.height = "100%";
    document.getElementById('draggable${id}').style.top = "0%";
    document.getElementById('draggable${id}').style.left = "0%";
    document.getElementById('frame${id}').style.opacity = "1";
  }
  function unload${id}() {
    document.getElementById("container${id}").remove();
    windowInstances = windowInstances.filter(e => e !== '${id}');
  }
  function updatezindex${id}() {
    // Position it absolutely, so that we can bring to front
    document.getElementById("container${id}").style.position = 'absolute';
    // Update Z-Index To Bring-To-Front
    z_index_counter += 1;
    document.getElementById("container${id}").style.zIndex = z_index_counter;
    // Position it relatively, so that we can let x, y, width, and height be modified by $().draggable()
    document.getElementById("container${id}").style.position = 'relative';
  }
<\/script>
<div class="background" aria-label="windowContent" id="container${id}" class="ui-widget-content" onmousedown="updatezindex${id}()" >
  <div class="window blue glass active" aria-label="windowContent2" id="draggable${id}">
    <div class="title-bar">
      <div class="title-bar-text">
        <img src='${faviconlink}' style='display:inline-block;width:16px;height:16px;' />
        ${title}
      </div>
      <div class="title-bar-controls glass">
        <button class="controls-indiv-btn" aria-label="Minimize" onclick="minm${id}()"><?php PrintIf11('[_]'); ?></button>
        <button class="controls-indiv-btn" aria-label="Maximize" onclick="launchFullScreen('frame${id}')"><?php PrintIf11('[o]'); ?></button>
        <button class="controls-indiv-btn" aria-label="Close" onclick='unload${id}();'><?php PrintIf11('[x]'); ?></button>
      </div>
    </div>
    <div class="window-body" id="resizable${id}" max-width="100%" max-height="100%" style="border-radius: 8px 8px 8px 8px;">
      <iframe src="${link}" id="frame${id}" allowfullscreen/>
    </div>
  </div>
</div>
<script>
         $(document).ready(function() {
         isBeingResized${id} = false;
         isBeingDragged${id} = false;
          $('#frame${id}').css('pointer-events', 'auto');
          $('#resizable${id}').resizable({
            start: function(event, ui) {
              $('#frame${id}').css('pointer-events','none');isBeingResized${id} = true;
           },
            stop: function(event, ui) {
              $('#frame${id}').css('pointer-events','auto');isBeingResized${id} = false;
            }
          });
          $('#draggable${id}').draggable({
            start: function(event, ui) {
              $('#frame${id}').css('pointer-events','none');isBeingDragged${id} = true;
           },
            stop: function(event, ui) {
              $('#frame${id}').css('pointer-events','auto');isBeingDragged${id} = false;
            }
          });
        });//Make it so iframe glitch drag,resize fix
<\/script>
`
  //Sync Range slider - bugfix
  $('div[id^=\'container\']').css( "left", document.getElementById('slider').value);
  //Add HTML
  $( "#winbox" ).append(html_template);
  //RESIZABLE+DRAGGABLE Bugfix1
  $( "#resizable" + id ).resizable({
    start: function(event, ui) {
      $('#frame' + id).css('pointer-events', 'none');
    },
    stop: function(event, ui) {
      $('#frame' + id).css('pointer-events', 'auto');
    }
  });
  $( "#draggable" + id ).draggable({
    start: function(event, ui) {
      $('#frame' + id).css('pointer-events', 'none');
    },
    stop: function(event, ui) {
      $('#frame' + id).css('pointer-events', 'auto');
    }
  });
}

function populateApp() {
  appname = document.getElementById("apps");
  if (appname.value == "about:blank") {
    return;
  }
  if (appname.value.includes("CSTM: ")) {
    window.open(appname.value.replace("CSTM: ",""), "Custom App", "popup");
  } else {
    new_window("ripbozo"+Date.now().toString().replaceAll(".",""),
              appname.value,
              $("#apps option:selected").text());
  }
  $('#apps').prop('selectedIndex', 0);
}

function InstallApp(appname, apphref) {
  document.getElementById("apps").innerHTML += '    <option value="'+apphref+'">'+appname+'</option>';
} // 

new_window("ndisp_bugfix_temp", "about:blank", "ndisp_bugfix_temp");
document.getElementById("ndisp_bugfix_temp").style.display = 'none';

//RESIZABLE Bugfix2
$(".ui-resizable-handle").click(function () {
    $('iframe').css('pointer-events', 'none');
});
$(".title-bar").click(function () {
    $('iframe').css('pointer-events', 'none');
});

</script>
