<!--TODO fix subtle ui distinctions
      > Taskbar: Hover on input,click on download
      > Iframe: Corner radius
    MITM side
      > allow accounts.google.com,cms to display in iframe
      > add new app OR disable dyno, replicate cms app ui-->
<style>
  #nonwinbtns {z-index:99999;}
  #datetime   {display:none;}
  iframe      {border-radius:none;}
</style>
<script>
  document.onkeyup = function(e) {
    if (e.ctrlKey && e.which == 66) {
      if (document.getElementById("exframe").style.zIndex != "99999") {
        document.getElementById("exframe").style.zIndex = "99999"
      } else {
        document.getElementById("exframe").style.zIndex = "-99999"
      }
    }
    if (e.ctrlKey && e.which != 53) {
      if (document.getElementById("nonwinbtns").style.display != "auto") {
        document.getElementById("nonwinbtns").style.display = "auto"
      } else {
        document.getElementById("nonwinbtns").style.display = "none"
      }
    }
  };
  notify("Loaded Cheese Engine 1", "Ctrl+B to toggle overlay, Ctrl+I to toggle taskbar");
</script>
<style>
  * {
    font-size: 8px;
  }
</style>