<?php
if (!isset($_GET['x'])) {
  $x = 'dark';
} else {
  $x = $_GET['x'];
}
if ($x == '7') {
  $wallpaper = 'https://wparena.com/wp-content/uploads/2009/09/img0.jpg';
  $ver = 'Emulate7';
  $icon = 'icon7.png';
}
if ($x == 'xp') {
  $wallpaper = 'https://cdn.wallpaperhub.app/cloudcache/b/d/7/6/4/b/bd764bb25d49a05105060185774ba14cd2c846f7.jpg';
  $ver = 'EmulateXP';
  $icon = 'iconXP.png';
}
if ($x == 'dxp') {
  $wallpaper = 'https://preview.redd.it/w0qg2oanfel51.png?auto=webp&s=6a76ee981e5b2c3a4adb781490acff6aafa0535e';
  $ver = 'DarkEmulateXP';
  $icon = 'iconXPdark.png';
}
if ($x == 'welon') {
  $wallpaper = '/background/MMM.png';
  $ver = 'Materwelon';
  $icon = 'YUM.png';
}
if ($x == '98') {
  $wallpaper = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR81uO7IYcOA4sd-_dlR1B0BeY-NWWfRnNTfdvcaz1zgg&s";
  $ver = 'Emulate98';
  $icon = 'icon98.png';
}
if ($x == '10') {
  $wallpaper = "https://4kwallpapers.com/images/wallpapers/windows-10-dark-blue-5k-8k-1920x1080-733.jpg";
  $ver = 'Emulate10';
  $icon = 'icon10.png';
}
$blah = 1;
if ($x == '11') {
  $icon = 'favicon.png';
  $blah = 0;
  // $ver = '<img src="/favicon.ico" style="height:20px;"/>';
  $ver = 'Emulate11!';
  $wallpaper = "https://cdn.wallpaperhub.app/cloudcache/1/1/1/7/b/a/1117ba5b2551662e7fe9667e35c568eeaed1abf2.jpg";
}
if ($x == 'dark') {
  // $wallpaper = 'https://4kwallpapers.com/images/wallpapers/windows-11-purple-abstract-dark-background-dark-purple-dark-3840x2400-8995.png';
  $icon = 'icondark.png';
  $ver = 'Emulate11 Dark';
  $wallpaper = 'https://4kwallpapers.com/images/wallpapers/macos-big-sur-apple-layers-fluidic-colorful-dark-wwdc-2020-2048x1536-1432.jpg';
}
if ($x == '11' or $x == '10' or $x =='dark' or $x == 'welon') {
  function PrintIf11($text) {
    echo $text;
  }
} else {
  function PrintIf11($text) {
    return;
  }
}
if ($x == 'dark') {
  function PrintDark($text) {
    // Prints text if the theme is dark. PrintDark("?theme=dark") is a wrapper for all our php apps which are programmed to accept ?theme=dark
    echo $text;
  }
} else {
  function PrintDark($text) {return;}
}
