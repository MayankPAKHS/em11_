<style id="msstyles">
  * {
    cursor: url("http://www.rw-designer.com/cursor-extern.php?id=135794");
  }
  body {
	  background-image: url("<?php echo $wallpaper;?>");
    background-size:     cover;/* was cover*/
    background-repeat:   no-repeat;
    background-position: center;              /* optional, center the image */
    overflow: hidden;
    max-width: 100%;
    max-height: 100%;
  }
  @supports (-moz-appearance:none) {
    body {
      height: 100%;
      overflow: hidden;
    }
  }
  .background {
    width: fit-content;
    height: fit-content;
  }
  iframe {
    border: none;
    outline: none;
    width: 100%;
    height: 100%;
  }
  a {
    color: white;
  }
</style>
