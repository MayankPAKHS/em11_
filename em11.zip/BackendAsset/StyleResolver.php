<?php
  // Following code determines which stylesheet to link based on theme.
  // If stylesheet isn't locally hosted it gets from unpkg
  if ($x == '11' or $x == '10') {
      $src = 'styles/style.css';
  }
  if ($x != '11' and $x != '10' and $x != 'dark') {
      $src = 'https://unpkg.com/'.$x.'.css';
  }
  if ($x == 'dark') {
      $src = 'styles/style.css';
  }
  if ($x == 'dxp') {
      $src = 'styles/DXP.css';
  }
  if ($x == 'welon') {
      $src = 'styles/WELON.css';
  }
  // if ($x == 'se')
  echo "<style>".file_get_contents($src)."</style>";
?>