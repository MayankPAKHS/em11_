<!-- demo1.html -->
<html>
  <head>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <style>
            body, html
            {
                margin: 0; padding: 0; height: 100%; overflow: hidden;
            }

            iframe
            {
                position:absolute; left: 0; right: 0; bottom: 0; top: 0px;  outline:none;border:none;width:100vw;height:100vh;
            }
    </style>
</head>
<body>
<iframe id="myIframe" src="https://kahoot.it/"></iframe>
<script>
// alert(window.self !== window.top); Worked!
$( document ).ready(function() {
  var iframe1 = document.getElementById('myIframe');
  var kahootpage = iframe1.innerHTML;
  var xsstester = "<button onclick='alert(window.self !== window.top)' id='xssiframebtn'> Jq <\/button>";
  // iframe1.contentDocument
  document.write(xsstester+kahootpage);
  // iframe1.contentWindow.document.getElementById("xssiframebtn").click();
})
</script>
</body>
</html>